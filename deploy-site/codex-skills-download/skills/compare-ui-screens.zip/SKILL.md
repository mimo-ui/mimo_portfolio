---
name: compare-ui-screens
description: Compare old and new UI screenshots, identify evidence-based UX and visual changes, and produce concise portfolio-ready design analysis. Use when Codex needs to analyze before/after product screens, summarize redesign rationale and user value, create comparison tables, or insert paired screenshots and analysis into an HTML portfolio case study.
---

# Compare UI Screens

Turn before/after interface screenshots into concise, evidence-based design analysis and, when requested, a polished portfolio comparison section.

## Workflow

1. Inspect each screenshot independently before comparing them.
2. Identify the screen type, user state, primary task, key information, and main CTA.
3. Compare only visible evidence across these dimensions:
   - title, status, and message hierarchy;
   - navigation and task flow;
   - information fields and density;
   - trust, safety, and risk cues;
   - CTA priority and emotional fit;
   - visual hierarchy and cross-screen consistency.
4. Select the 3–6 changes with the greatest user impact. Merge overlapping observations.
5. For every change, state `old → new → why it matters`. Do not invent research findings, intent, or performance metrics.
6. End with a compact benefit summary. Use the user's language unless asked otherwise.

## Output Contract

Use this structure by default:

```text
屏幕类型：<screen and user state>

改动分析
1. <dimension> — 旧：<visible evidence>。新：<visible evidence>。价值：<user or business effect>。

核心收益
| 维度 | 提升点 |
| --- | --- |
| <dimension> | <one concise benefit> |
```

Keep headings short and paragraphs scannable. Prefer specific interface language over generic praise such as “更美观” or “体验更好”.

## Portfolio HTML Updates

When the user asks to place the comparison in an existing portfolio:

1. Preserve the source screenshots and copy them into the project's asset directory with semantic filenames.
2. Render exactly one old and one new screenshot in paired cards.
3. Give both cards equal visual height, preserve image aspect ratios, center the screens, and use consistent labels, padding, borders, and radii.
4. Stack the cards on narrow screens and keep desktop comparison side by side.
5. Replace placeholders and outdated analysis instead of appending duplicate content.
6. Add useful `alt` text and lazy loading.
7. Verify asset paths, image count, placeholder removal, responsive rules, and script or markup syntax after editing.

## Quality Checklist

- Ground every claim in visible screenshot evidence.
- Explain the change in user perspective, trust, effort, clarity, or next-step guidance.
- Keep terminology consistent with the interface.
- Preserve important tradeoffs; do not force every change to sound positive.
- Remove repetition between detailed analysis and the benefit table.
