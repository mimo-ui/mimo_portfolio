#!/usr/bin/env python3
"""
compare.py — Figma UI Checker
像素级对比 + 设计规格对比，生成综合 HTML 报告
"""

import argparse
import base64
import json
import os
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw
    import numpy as np
    from skimage.metrics import structural_similarity as ssim
except ImportError:
    print("Missing dependencies. Install with: python3 -m pip install -r scripts/requirements.txt")
    sys.exit(1)

PIXEL_WEIGHT = 0.45
STRUCTURAL_WEIGHT = 0.55

GRADE_THRESHOLDS = [(95, "A"), (90, "B"), (80, "C"), (70, "D"), (0, "F")]
GRADE_COLORS = {"A": "#16a34a", "B": "#65a30d", "C": "#ca8a04", "D": "#ea580c", "F": "#dc2626"}
STATUS_EMOJI = {"match": "✅", "close": "🟡", "mismatch": "🔴", "missing": "—"}


def grade(score):
    for t, g in GRADE_THRESHOLDS:
        if score >= t:
            return g
    return "F"


def slugify(name):
    return name.lower().replace(" ", "_").replace("/", "_")


def resize_to_match(img, target):
    tw, th = target.size
    ir = img.width / img.height
    tr = tw / th
    if abs(ir - tr) < 0.05:
        return img.resize((tw, th), Image.LANCZOS)
    if ir > tr:
        nw, nh = tw, int(tw / ir)
    else:
        nw, nh = int(th * ir), th
    resized = img.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGB", (tw, th), (255, 255, 255))
    canvas.paste(resized, ((tw - nw) // 2, (th - nh) // 2))
    return canvas


def compute_scores(figma_arr, app_arr, threshold=0.05):
    diff = np.abs(figma_arr.astype(np.int32) - app_arr.astype(np.int32))
    diff_norm = diff.max(axis=2) / 255.0
    mask = diff_norm > threshold
    pixel_score = 100 * (1 - mask.mean())
    ssim_score = max(0.0, ssim(figma_arr, app_arr, channel_axis=2, data_range=255) * 100)
    blended = PIXEL_WEIGHT * pixel_score + STRUCTURAL_WEIGHT * ssim_score
    return pixel_score, ssim_score, blended, mask


def make_diff_image(figma_img, app_img, mask):
    base = Image.blend(figma_img, app_img, alpha=0.5).convert("RGBA")
    overlay = Image.new("RGBA", figma_img.size, (0, 0, 0, 0))
    px = overlay.load()
    h, w = mask.shape
    for y in range(h):
        for x in range(w):
            if mask[y, x]:
                px[x, y] = (220, 38, 38, 180)
    return Image.alpha_composite(base, overlay).convert("RGB")


def analyze_regions(mask):
    h = mask.shape[0]
    t = h // 3
    return {
        "top": float(mask[:t].mean() * 100),
        "middle": float(mask[t:2*t].mean() * 100),
        "bottom": float(mask[2*t:].mean() * 100),
    }


def img_b64(path):
    try:
        with open(path, "rb") as f:
            return "data:image/png;base64," + base64.b64encode(f.read()).decode()
    except Exception:
        return ""


def compare_pair(pair, output_dir, threshold=0.05, crop_top=0):
    name = pair.get("name", Path(pair["figma"]).stem)
    slug = slugify(name)

    figma_img = Image.open(pair["figma"]).convert("RGB")
    app_img = Image.open(pair["app"]).convert("RGB")
    if crop_top > 0:
        app_img = app_img.crop((0, crop_top, app_img.width, app_img.height))
    app_img = resize_to_match(app_img, figma_img)

    figma_arr, app_arr = np.array(figma_img), np.array(app_img)
    pixel_score, ssim_score, blended, mask = compute_scores(figma_arr, app_arr, threshold)

    diff_img = make_diff_image(figma_img, app_img, mask)
    diffs_dir = output_dir / "diffs"
    diffs_dir.mkdir(parents=True, exist_ok=True)

    diff_path = diffs_dir / f"{slug}_diff.png"
    app_resized_path = diffs_dir / f"{slug}_app.png"
    diff_img.save(diff_path)
    app_img.save(app_resized_path)

    # Load specs if available
    specs_data = {}
    if pair.get("specs") and Path(pair["specs"]).exists():
        with open(pair["specs"]) as f:
            specs_data = json.load(f)

    return {
        "name": name, "slug": slug,
        "pixel_score": round(pixel_score, 1),
        "ssim_score": round(ssim_score, 1),
        "blended_score": round(blended, 1),
        "grade": grade(blended),
        "figma_path": pair["figma"],
        "app_path": str(app_resized_path),
        "diff_path": str(diff_path),
        "regions": analyze_regions(mask),
        "specs": specs_data,
    }


def render_specs_table(specs_data):
    if not specs_data:
        return '<p style="color:#9ca3af;font-size:12px">暂无设计规格数据（需要 Figma 桌面 App 选中图层后调用 get_design_context）</p>'

    figma_specs = specs_data.get("figma_specs", {})
    comparison = specs_data.get("comparison", [])

    if comparison:
        rows_html = ""
        for row in comparison:
            emoji = STATUS_EMOJI.get(row["status"], "—")
            bg = "#fef2f2" if row["status"] == "mismatch" else "#fffbeb" if row["status"] == "close" else "#f0fdf4" if row["status"] == "match" else "#f9fafb"
            rows_html += f"""<tr style="background:{bg}">
              <td style="padding:6px 10px;color:#6b7280;font-size:11px">{row['category']}</td>
              <td style="padding:6px 10px;font-size:12px;font-weight:500">{row['property']}</td>
              <td style="padding:6px 10px;font-size:12px;font-family:monospace">{row['figma']}</td>
              <td style="padding:6px 10px;font-size:12px;font-family:monospace">{row['app']}</td>
              <td style="padding:6px 10px;text-align:center">{emoji}</td>
            </tr>"""
        return f"""<table style="width:100%;border-collapse:collapse;font-size:12px">
          <thead><tr style="background:#f9fafb">
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">类别</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">属性</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">Figma 设计值</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">App 实现值</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">状态</th>
          </tr></thead>
          <tbody>{rows_html}</tbody>
        </table>"""
    elif figma_specs:
        rows_html = ""
        for category, props in figma_specs.items():
            for prop, val in props.items():
                rows_html += f"""<tr>
                  <td style="padding:6px 10px;color:#6b7280;font-size:11px">{category}</td>
                  <td style="padding:6px 10px;font-size:12px;font-weight:500">{prop}</td>
                  <td style="padding:6px 10px;font-size:12px;font-family:monospace">{val}</td>
                  <td style="padding:6px 10px;font-size:12px;color:#9ca3af">—（待测量）</td>
                  <td style="padding:6px 10px;text-align:center">—</td>
                </tr>"""
        return f"""<table style="width:100%;border-collapse:collapse;font-size:12px">
          <thead><tr style="background:#f9fafb">
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">类别</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">属性</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">Figma 设计值</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">App 实现值</th>
            <th style="padding:6px 10px;text-align:left;color:#6b7280;font-size:11px">状态</th>
          </tr></thead>
          <tbody>{rows_html}</tbody>
        </table>"""
    return '<p style="color:#9ca3af;font-size:12px">无规格数据</p>'


def generate_html(scores, output_dir):
    overall = sum(s["blended_score"] for s in scores) / len(scores)
    og = grade(overall)
    oc = GRADE_COLORS.get(og, "#6b7280")

    cards_html = ""
    summary_rows = ""

    for s in scores:
        color = GRADE_COLORS.get(s["grade"], "#6b7280")
        figma_b64 = img_b64(s["figma_path"])
        app_b64 = img_b64(s["app_path"])
        diff_b64 = img_b64(s["diff_path"])
        r = s["regions"]

        def rbar(v, label):
            pct = min(100, v)
            c = "#ef4444" if pct > 20 else "#f97316" if pct > 10 else "#22c55e"
            return f'<div style="margin:2px 0;font-size:11px;color:#555">{label}: <span style="display:inline-block;width:{pct:.0f}px;height:7px;background:{c};border-radius:2px;vertical-align:middle"></span> {pct:.1f}%</div>'

        specs_table = render_specs_table(s.get("specs", {}))

        cards_html += f"""
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px;margin-bottom:28px;box-shadow:0 1px 3px rgba(0,0,0,.07)">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
            <span style="font-size:18px;font-weight:700;color:#111">{s['name']}</span>
            <span style="font-size:26px;font-weight:800;color:{color}">{s['grade']}</span>
            <span style="font-size:15px;color:{color};font-weight:600">{s['blended_score']}%</span>
            <span style="margin-left:auto;font-size:12px;color:#9ca3af">像素:{s['pixel_score']}% &nbsp;结构:{s['ssim_score']}%</span>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
            <div><div style="font-size:11px;color:#9ca3af;text-align:center;margin-bottom:4px">Figma 设计稿</div>
              <img src="{figma_b64}" style="width:100%;border-radius:6px;border:1px solid #e5e7eb"></div>
            <div><div style="font-size:11px;color:#9ca3af;text-align:center;margin-bottom:4px">App 截图</div>
              <img src="{app_b64}" style="width:100%;border-radius:6px;border:1px solid #e5e7eb"></div>
            <div><div style="font-size:11px;color:#9ca3af;text-align:center;margin-bottom:4px">差异叠加（红=不一致）</div>
              <img src="{diff_b64}" style="width:100%;border-radius:6px;border:1px solid #e5e7eb"></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div style="background:#f9fafb;padding:10px;border-radius:6px">
              <div style="font-size:11px;font-weight:600;color:#374151;margin-bottom:6px">📍 像素差异区域分布</div>
              {rbar(r['top'], '顶部')}
              {rbar(r['middle'], '中部')}
              {rbar(r['bottom'], '底部')}
            </div>
            <div style="background:#f9fafb;padding:10px;border-radius:6px">
              <div style="font-size:11px;font-weight:600;color:#374151;margin-bottom:6px">📐 设计规格对比</div>
              {specs_table}
            </div>
          </div>
        </div>"""

        bar_w = int(s["blended_score"])
        summary_rows += f"""<tr>
          <td style="padding:8px 12px;font-weight:500">{s['name']}</td>
          <td style="padding:8px 12px">
            <div style="display:flex;align-items:center;gap:8px">
              <div style="flex:1;background:#f3f4f6;border-radius:4px;height:10px">
                <div style="width:{bar_w}%;background:{color};height:10px;border-radius:4px"></div>
              </div>
              <span style="font-size:13px;color:{color};font-weight:600;min-width:44px">{s['blended_score']}%</span>
            </div>
          </td>
          <td style="padding:8px 12px;text-align:center;font-weight:700;color:{color}">{s['grade']}</td>
        </tr>"""

    grade_legend = "".join(
        f'<tr><td style="padding:2px 8px;font-size:12px;color:{c};font-weight:600">{g} {t}%+</td><td style="padding:2px 8px;font-size:12px;color:#6b7280">{d}</td></tr>'
        for (t, g), c, d in zip(GRADE_THRESHOLDS[:-1], ["#16a34a","#65a30d","#ca8a04","#ea580c"], ["完美还原","细微偏差","建议检查","明显偏差"])
    ) + '<tr><td style="padding:2px 8px;font-size:12px;color:#dc2626;font-weight:600">F &lt;70%</td><td style="padding:2px 8px;font-size:12px;color:#6b7280">需要返工</td></tr>'

    html = f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>UI 走查报告</title>
<style>body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f1f5f9;margin:0;padding:24px;color:#111}}</style>
</head><body>
<h1 style="font-size:22px;font-weight:800;margin:0 0 4px">📱 UI 走查报告</h1>
<p style="color:#6b7280;font-size:13px;margin:0 0 20px">共 {len(scores)} 个页面 · 像素差异 + 设计规格对比</p>
<div style="background:#fff;border-radius:12px;padding:20px;margin-bottom:24px;display:flex;align-items:center;gap:20px;box-shadow:0 1px 3px rgba(0,0,0,.08)">
  <div><div style="font-size:12px;color:#6b7280">整体还原度</div>
    <div style="font-size:44px;font-weight:900;color:{oc}">{overall:.1f}%</div></div>
  <div style="font-size:60px;font-weight:900;color:{oc}">{og}</div>
  <div style="margin-left:auto"><table style="border-collapse:collapse;background:transparent">{grade_legend}</table></div>
</div>
<table style="width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.08);margin-bottom:24px">
  <thead><tr>
    <th style="background:#f9fafb;padding:10px 12px;font-size:12px;color:#6b7280;text-align:left;border-bottom:1px solid #e5e7eb">页面</th>
    <th style="background:#f9fafb;padding:10px 12px;font-size:12px;color:#6b7280;text-align:left;border-bottom:1px solid #e5e7eb">还原度</th>
    <th style="background:#f9fafb;padding:10px 12px;font-size:12px;color:#6b7280;text-align:left;border-bottom:1px solid #e5e7eb">等级</th>
  </tr></thead>
  <tbody>{summary_rows}</tbody>
</table>
{cards_html}
</body></html>"""

    path = output_dir / "report.html"
    path.write_text(html, encoding="utf-8")
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pairs", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--threshold", type=float, default=0.05)
    parser.add_argument("--crop-top", type=int, default=0)
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(args.pairs) as f:
        pairs = json.load(f)

    print(f"\nComparing {len(pairs)} screen(s)...\n")
    scores = []
    for pair in pairs:
        name = pair.get("name", Path(pair["figma"]).stem)
        try:
            result = compare_pair(pair, output_dir, args.threshold, args.crop_top)
            scores.append(result)
            print(f"  {result['name']:<25} {result['blended_score']:5.1f}% [{result['grade']}]")
        except Exception as e:
            print(f"  {name}: ERROR — {e}", file=sys.stderr)

    if not scores:
        sys.exit(1)

    overall = sum(s["blended_score"] for s in scores) / len(scores)
    print(f"\n{'='*50}")
    print(f"  整体还原度: {overall:.1f}%  总评: {grade(overall)}")
    print(f"{'='*50}\n")

    with open(output_dir / "scores.json", "w") as f:
        json.dump({"overall": round(overall, 1), "grade": grade(overall), "screens": scores}, f, ensure_ascii=False, indent=2)

    report_path = generate_html(scores, output_dir)
    print(f"报告: {report_path}")


if __name__ == "__main__":
    main()
