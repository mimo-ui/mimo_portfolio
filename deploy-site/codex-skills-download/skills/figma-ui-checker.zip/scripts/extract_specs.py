#!/usr/bin/env python3
"""
extract_specs.py — 从 get_design_context 返回的 CSS/代码中提取设计规格
输出 JSON 格式的字体、间距、颜色 token
"""

import argparse
import json
import re
import sys


# ── CSS 属性提取规则 ──────────────────────────────────────────────────────────

FONT_PROPS = [
    "font-size", "font-weight", "font-family", "line-height",
    "letter-spacing", "text-transform", "font-style",
]
SPACING_PROPS = [
    "padding", "padding-top", "padding-right", "padding-bottom", "padding-left",
    "margin", "margin-top", "margin-right", "margin-bottom", "margin-left",
    "gap", "row-gap", "column-gap",
]
SHAPE_PROPS = [
    "border-radius", "border-top-left-radius", "border-top-right-radius",
    "border-bottom-left-radius", "border-bottom-right-radius",
    "width", "height", "min-width", "max-width", "min-height", "max-height",
]
COLOR_PROPS = ["color", "background-color", "border-color", "background", "border"]


def extract_css_props(css_text: str, prop_names: list[str]) -> dict:
    """Extract CSS property values from a block of CSS text."""
    result = {}
    for prop in prop_names:
        # Match "prop: value;" patterns
        pattern = rf'(?<![a-z-]){re.escape(prop)}\s*:\s*([^;{{}}]+)'
        matches = re.findall(pattern, css_text, re.IGNORECASE)
        if matches:
            # Take the last (most specific) value
            val = matches[-1].strip().rstrip(';').strip()
            result[prop] = val
    return result


def extract_from_react_jsx(code: str) -> dict:
    """Extract inline style values from React/JSX style props."""
    result = {}
    # Match style={{ key: 'value' }} patterns
    style_blocks = re.findall(r'style=\{[{]([^}]+)[}]\}', code, re.DOTALL)
    for block in style_blocks:
        # camelCase to kebab-case
        pairs = re.findall(r'(\w+)\s*:\s*[\'"]?([^\'"`,\n]+)[\'"]?', block)
        for key, val in pairs:
            kebab = re.sub(r'([A-Z])', r'-\1', key).lower()
            result[kebab] = val.strip().rstrip(',')
    return result


def extract_from_tailwind(code: str) -> dict:
    """Best-effort extraction from Tailwind class names."""
    result = {}
    # Font size: text-sm text-base text-lg text-xl text-2xl etc.
    tailwind_font_sizes = {
        "text-xs": "12px", "text-sm": "14px", "text-base": "16px",
        "text-lg": "18px", "text-xl": "20px", "text-2xl": "24px",
        "text-3xl": "30px", "text-4xl": "36px",
    }
    for cls, size in tailwind_font_sizes.items():
        if cls in code:
            result["font-size"] = size
            break

    # Font weight
    tailwind_weights = {
        "font-thin": "100", "font-extralight": "200", "font-light": "300",
        "font-normal": "400", "font-medium": "500", "font-semibold": "600",
        "font-bold": "700", "font-extrabold": "800", "font-black": "900",
    }
    for cls, weight in tailwind_weights.items():
        if cls in code:
            result["font-weight"] = weight
            break

    # Padding: p-4 = 16px, p-6 = 24px etc.
    pad_match = re.search(r'\bp-(\d+)\b', code)
    if pad_match:
        result["padding"] = f"{int(pad_match.group(1)) * 4}px"

    # Gap: gap-2 = 8px etc.
    gap_match = re.search(r'\bgap-(\d+)\b', code)
    if gap_match:
        result["gap"] = f"{int(gap_match.group(1)) * 4}px"

    # Border radius
    tailwind_radius = {
        "rounded-none": "0", "rounded-sm": "2px", "rounded": "4px",
        "rounded-md": "6px", "rounded-lg": "8px", "rounded-xl": "12px",
        "rounded-2xl": "16px", "rounded-full": "9999px",
    }
    for cls, radius in tailwind_radius.items():
        if cls in code:
            result["border-radius"] = radius
            break

    return result


def group_specs(raw: dict) -> dict:
    """Group extracted properties into typography, spacing, shape, color."""
    grouped = {
        "typography": {},
        "spacing": {},
        "shape": {},
        "color": {},
        "other": {},
    }
    for key, val in raw.items():
        if key in FONT_PROPS:
            grouped["typography"][key] = val
        elif key in SPACING_PROPS:
            grouped["spacing"][key] = val
        elif key in SHAPE_PROPS:
            grouped["shape"][key] = val
        elif key in COLOR_PROPS:
            grouped["color"][key] = val
        else:
            grouped["other"][key] = val
    # Remove empty groups
    return {k: v for k, v in grouped.items() if v}


def extract_all(code: str) -> dict:
    """Try all extraction strategies and merge results."""
    merged = {}

    # CSS extraction
    all_css_props = FONT_PROPS + SPACING_PROPS + SHAPE_PROPS + COLOR_PROPS
    css_result = extract_css_props(code, all_css_props)
    merged.update(css_result)

    # React inline styles
    jsx_result = extract_from_react_jsx(code)
    for k, v in jsx_result.items():
        if k not in merged:
            merged[k] = v

    # Tailwind classes
    tw_result = extract_from_tailwind(code)
    for k, v in tw_result.items():
        if k not in merged:
            merged[k] = v

    return group_specs(merged)


def compare_specs(figma_specs: dict, app_specs: dict) -> list[dict]:
    """
    Compare Figma design specs against app specs (if provided).
    Returns a list of comparison rows.
    """
    rows = []
    all_categories = set(list(figma_specs.keys()) + list(app_specs.keys()))
    for category in sorted(all_categories):
        figma_cat = figma_specs.get(category, {})
        app_cat = app_specs.get(category, {})
        all_props = set(list(figma_cat.keys()) + list(app_cat.keys()))
        for prop in sorted(all_props):
            figma_val = figma_cat.get(prop, "—")
            app_val = app_cat.get(prop, "—")
            if figma_val == "—" or app_val == "—":
                status = "missing"
            elif figma_val == app_val:
                status = "match"
            else:
                # Try numeric comparison
                def parse_px(v):
                    m = re.match(r'^([\d.]+)px$', str(v).strip())
                    return float(m.group(1)) if m else None
                fv, av = parse_px(figma_val), parse_px(app_val)
                if fv is not None and av is not None:
                    diff = abs(fv - av)
                    status = "close" if diff <= 2 else "mismatch"
                else:
                    status = "mismatch"
            rows.append({
                "category": category,
                "property": prop,
                "figma": figma_val,
                "app": app_val,
                "status": status,
            })
    return rows


def main():
    parser = argparse.ArgumentParser(description="Extract design specs from Figma get_design_context output")
    parser.add_argument("--css", help="CSS/code string from get_design_context (or use --input-file)")
    parser.add_argument("--input-file", help="File containing the code string")
    parser.add_argument("--app-specs", help="JSON file with app specs for comparison")
    parser.add_argument("--output", required=True, help="Output JSON file path")
    args = parser.parse_args()

    if args.input_file:
        with open(args.input_file) as f:
            code = f.read()
    elif args.css:
        code = args.css
    else:
        print("Error: provide --css or --input-file", file=sys.stderr)
        sys.exit(1)

    figma_specs = extract_all(code)

    # Load app specs for comparison if provided
    app_specs = {}
    if args.app_specs:
        try:
            with open(args.app_specs) as f:
                app_specs = json.load(f)
        except Exception:
            pass

    output = {
        "figma_specs": figma_specs,
        "comparison": compare_specs(figma_specs, app_specs) if app_specs else [],
    }

    import os
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # Pretty print to console
    print("\n=== 设计规格提取结果 ===\n")
    for category, props in figma_specs.items():
        print(f"[{category.upper()}]")
        for prop, val in props.items():
            print(f"  {prop:<30} {val}")
    print(f"\n已保存到: {args.output}")


if __name__ == "__main__":
    main()
