---
name: figma-ui-checker
description: UI design QA workflow for comparing Figma frames with implemented app screenshots. Use when the user asks for Figma UI review, design fidelity checking, pixel diff, UI acceptance, visual regression against Figma, typography/spacing/radius/color inspection, or asks how close an app screen is to a design. Inputs are usually a Figma design URL or node id plus one or more app screenshots.
---

# Figma UI Checker

Use this workflow to compare Figma design frames against app screenshots and produce a practical UI acceptance report with screenshots, diff overlays, scores, and extracted Figma specs.

## Workflow

1. Parse the Figma URL. Extract `fileKey` and `nodeId`; convert URL node ids from `1-2` to `1:2`.
2. Use Figma MCP tools to collect design inputs:
   - Use `get_metadata` when the user supplied only a file URL and you need candidate frames.
   - Use `get_screenshot` for each target frame and save the PNG.
   - Use `get_design_context` for each target frame when available; save the returned code/CSS text to a file before parsing it.
3. Collect app screenshots:
   - Prefer real uploaded screenshot files.
   - If the screenshot only appears inline in the conversation and no file is available, do a manual visual review and skip pixel diff.
   - If a local app must be captured, use the available browser/computer/app tooling for the current task, then save screenshots as PNG.
4. Extract Figma specs with `scripts/extract_specs.py`.
5. Create `pairs.json` mapping each Figma screenshot to the corresponding app screenshot and optional specs file.
6. Run `scripts/compare.py` to generate `report.html`, diff images, and `scores.json`.
7. Summarize the highest-impact differences in the final answer and link the generated report path.

## Working Directory

Create a run directory inside the current workspace, not `/tmp`, so the user can keep the artifacts:

```text
outputs/figma-ui-checker/<run-name>/
  figma/
  app/
  specs/
  context/
  report/
  pairs.json
```

Use stable lowercase slugs for file names, for example `home.png`, `settings.png`, and `home_specs.json`.

## Extract Specs

Write the `get_design_context` response to a text file, then run:

```bash
python3 /path/to/figma-ui-checker/scripts/extract_specs.py \
  --input-file outputs/figma-ui-checker/<run-name>/context/home.txt \
  --output outputs/figma-ui-checker/<run-name>/specs/home_specs.json
```

If `get_design_context` fails because the Figma environment requires selected layers or inspect access, continue with screenshot diff and note that typography/spacing specs need manual Figma Inspect confirmation.

## Pair Screens

Create `pairs.json` like this:

```json
[
  {
    "name": "Home",
    "figma": "outputs/figma-ui-checker/run/figma/home.png",
    "app": "outputs/figma-ui-checker/run/app/home.png",
    "specs": "outputs/figma-ui-checker/run/specs/home_specs.json"
  }
]
```

If filenames do not clearly match, ask the user which app screenshot corresponds to each Figma frame.

## Run Comparison

Install dependencies only when missing:

```bash
python3 -m pip install -r /path/to/figma-ui-checker/scripts/requirements.txt
```

Then run:

```bash
python3 /path/to/figma-ui-checker/scripts/compare.py \
  --pairs outputs/figma-ui-checker/<run-name>/pairs.json \
  --output outputs/figma-ui-checker/<run-name>/report
```

Useful options:

- `--crop-top N` crops `N` pixels from the top of app screenshots before matching Figma dimensions.
- `--threshold 0.1` reduces sensitivity for dynamic content or antialiasing noise.

The scoring formula is `45% pixel match + 55% SSIM`. Grades are A `95+`, B `90-95`, C `80-90`, D `70-80`, F `<70`.

## Final Response

Keep the final answer short and actionable:

- Overall score and grade.
- The top 3-5 concrete visual issues, grouped by screen.
- Any missing inputs or caveats, especially skipped spec extraction or skipped pixel diff.
- Absolute path to `report/report.html` and any key diff PNGs.
