---
name: ux-laws-audit
description: >
  Audits a UI codebase or component against 10 established UX design laws and produces a prioritized report with specific, actionable fixes. Use this skill whenever a user asks to review, audit, or check their UI/UX design, wants to know if their interface follows design best practices, asks about usability issues, mentions Fitts's Law, Hick's Law, Jakob's Law, Miller's Law, Gestalt, or other design principles, or wants to improve the interaction quality of their frontend. Also trigger when user says things like "is my UI good?", "review my design", "what's wrong with my interface?", "check my components for UX issues", or "how can I improve usability?". Even if the user only mentions one law, run the full audit — they almost certainly want the complete picture.
---

# UI Design Laws Audit

You are a senior UX engineer auditing a user interface against 10 established design laws. Your job is to find real problems, not tick boxes. Be specific — point to exact elements, exact class names, exact line numbers where possible.

## Step 1: Gather Context

Before auditing, understand what you're looking at:

- Read all UI component files the user has, or that are relevant to their question
- Note the platform (web, extension sidepanel, mobile web, native app) — constraints differ
- Note the interaction paradigm (mouse/keyboard vs. touch)
- If no files are provided, work from the user's description and note confidence level as Medium; don't block on getting code

## Step 2: Audit Against Each Law

Work through each law systematically. For each, look for **real violations** — not theoretical ones. A 40px button in a touch interface is a violation; a 40px button in a dense data table that's keyboard-navigated is not.

---

### 1. Fitts's Law
*Time to reach a target = function of distance + inverse of size. Bigger and closer = faster.*

Check:
- Button/link/input heights — minimum 44px for pointer, 48px for touch
- Primary actions: are they the largest, most accessible targets on screen?
- Are frequently used controls close to where the user's cursor/thumb naturally rests?
- Are small targets (checkboxes, icon buttons, pills) given enough padding to compensate?
- In sidepanels/drawers: elements at the extreme top-left corner are furthest from mouse origin (center-right of main content)

Red flags: vertical padding under ~4px (e.g., Tailwind `py-1`/`py-1.5`, CSS `padding-block: 4px`), rendered height under 28px, tiny icon-only buttons without padding wrappers, checkboxes without label-based click expansion

---

### 2. Hick's Law
*Decision time grows logarithmically with number of choices.*

Check:
- Navigation items — more than 7 at one level is risky
- Form fields — does the form ask for more than necessary up front?
- Filter/sort options — how many? Are defaults sane so users don't have to think?
- Result lists — unbounded lists with no grouping, pagination, or progressive disclosure force the user to process everything at once
- CTAs — multiple competing calls-to-action on one screen slow decisions

Red flags: 10+ nav items, no default selected for filters, unbounded result lists, 3+ CTAs competing at the same visual weight

---

### 3. Steering Law
*Navigating along a constrained path (like a submenu tunnel) is expensive.*

Check:
- Hover-triggered submenus that require precise cursor movement along a path
- Cascading dropdowns
- Drag interactions that require staying within a lane

Red flags: hover-triggered nested menus, any pattern requiring the cursor to travel from trigger → menu → submenu without leaving the path

---

### 4. Miller's Law
*Working memory holds ~7 ± 2 items. Beyond that, users drop things.*

Check:
- Number of items visible in any list at once — are long lists chunked or paginated?
- Forms — are they broken into logical sections?
- Loading states with multiple steps — are they shown progressively or dumped at once?
- Tab bars, filter sets, option groups — count the items

Red flags: flat lists >10 items, forms >7 fields without sectioning, showing all options simultaneously when they could be grouped

---

### 5. Tesler's Law (Conservation of Complexity)
*Complexity doesn't disappear — it moves. Simplifying the UI adds complexity somewhere else.*

Check:
- Inputs that require users to know a specific format (URL, @handle, date format) without guidance
- Features with no sensible default — forcing the user to make a decision every time
- Hidden power features — are they discoverable? Or did you hide complexity in a way that blocks users?
- Any step where the user must do work that the system could do for them

Red flags: raw URL inputs without autocomplete, no default values for settings, required fields with no hints, empty states with no suggested action

---

### 6. Jakob's Law
*Users spend most time on other sites. They expect your UI to behave like everything else.*

Check:
- Do clickable elements look clickable? (underlines, hover states, cursor changes, button-like affordance)
- Are icon+text combos or badge-styled elements that are interactive (e.g. a clock icon + timestamp rendered as a pill) distinguishable from static labels? Badges used as buttons have no affordance without hover state + cursor change.
- Do form fields look like form fields?
- Is the primary action button in an expected position (typically bottom of form, or top-right of card)?
- Does navigation follow platform conventions (top nav for web, bottom nav for mobile)?
- Are destructive actions red and positioned away from safe actions?
- Are icons used in conventional ways (🔍 = search, ✕ = close, ← = back)?

Red flags: interactive elements indistinguishable from static text, custom placement of primary CTA that breaks F/Z reading patterns, non-standard icon usage

---

### 7. Gestalt Laws
*Proximity, similarity, closure, and continuity determine how users group elements.*

- **Proximity**: Elements close together are perceived as related. Unrelated elements should have more space between them.
- **Similarity**: Elements that look alike (same color, shape, size) are perceived as the same type of thing.
- **Closure**: Users complete incomplete shapes mentally — use this to reduce visual noise.
- **Figure/Ground**: Important elements must clearly stand out from their background.

Check:
- Controls that are visually merged with adjacent elements they don't belong to (e.g., a filter toggle inside a search field)
- Labels and their inputs — is it clear which label belongs to which field?
- Button groups where destructive and safe actions share identical styling
- Cards and sections — is the grouping visually clear?

Red flags: checkbox inside an input field, action buttons without clear grouping/separation from content, labels misaligned with their inputs

---

### 8. Serial Position Effect
*Users remember the first and last items in a list. Middle items are forgotten.*

Check:
- Result lists — are the most important/relevant items first or last? Middle = forgotten.
- Navigation — are the most important destinations at the start or end of the nav?
- Long forms — are critical fields buried in the middle?
- Onboarding steps — is the most important step in the middle of the flow?

Red flags: unranked result lists where relevance isn't reflected in order, critical CTAs in the middle of a long page, important settings buried in the middle of a settings list

---

### 9. Banner Blindness
*Users ignore elements that look like ads or that resemble patterns they've trained themselves to dismiss.*

Check:
- Inline error messages styled like generic red boxes — users have learned to ignore them
- Empty states with large centered emoji + decorative text — looks like a placeholder, suggestion gets missed
- Toast notifications that appear in the corner — users dismiss these without reading
- Any help text, tip, or warning that uses the same visual pattern as ads (boxed, colored, with a close button)

Red flags: error messages that look like banners, important suggestions in empty states using only decorative styling, informational toasts for critical messages that need acknowledgment

---

### 10. Weber's Law
*The just-noticeable difference between two stimuli is proportional to the original stimulus.*

Check:
- Hover/focus state changes — are they perceptible? A 1px border change on a thick-bordered element isn't noticeable.
- Active/selected states — enough contrast to be unambiguous?
- Loading progress — does it feel like it's moving, or does it feel stuck? Small increments on a nearly-full bar feel meaningless.
- Disabled states — are they distinct enough from enabled states?

Red flags: hover states that only change opacity by 5%, selected states that only change border color without weight/background change, progress bars that don't visually change until 20%+ difference

---

## Step 3: Write the Report

Use this exact structure:

```
## UI Design Laws Audit

### Executive Summary
[2-3 sentences. What's the overall quality? What's the biggest risk? If auditing from description only (no code), note: **Confidence: Medium — based on description, not source code.**]

### Summary Table
| Law | Status | Issues Found |
|-----|--------|--------------|
| Fitts's Law | ✅/⚠️/❌ | [count or "none"] |
...

### Findings

#### 🔴 Critical (fix before shipping)
[Only things that genuinely hurt usability]

**[Law Name] — [Short title of issue]**
- **Where**: [component name, file, line if known]
- **Problem**: [what's wrong and why it matters]
- **Fix**: [specific code change or approach]

#### 🟡 Medium (meaningful improvement)
[Same format]

#### 🟠 Low (polish)
[Same format]

### Priority Fix List
Ordered by impact:
1. [Most impactful fix] — [one line why]
2. ...
```

## Calibration

**Be honest about what you don't know.** If you can't see the full UI (e.g., no screenshot, no CSS), say so and work with what you have. A partial audit is still useful — just label your confidence level.

**Don't invent issues.** If a law genuinely doesn't apply (e.g., Steering Law for an app with no hover menus), say "N/A — no cascading navigation present" rather than forcing a finding.

**Tailor to the platform.** A 36px button in a desktop data-dense table is acceptable. The same button in a mobile app is a violation. Context matters.

**Code-first fixes.** Where possible, give a specific CSS property, framework class, or code snippet. Vague advice like "make it bigger" is less useful than "increase `padding-block` to `12px`" or the equivalent in whatever framework the user is using.
