# ux-laws-audit

An agent skill that audits any UI against 10 established UX design laws and produces a prioritized report with specific, actionable fixes.

Works with **Claude Code, Gemini CLI, Codex CLI, Cursor**, and any agent that supports the `SKILL.md` format. Works with any framework (React, Vue, Svelte, plain HTML/CSS) and any input — paste component code, describe your UI, or point the agent at your files.

---

## What it audits

| Law | What it catches |
|-----|----------------|
| **Fitts's Law** | Undersized targets, low-padding buttons, tiny checkboxes |
| **Hick's Law** | Too many nav items, competing CTAs, unbounded result lists |
| **Steering Law** | Hover-triggered cascading menus, cursor tunnels |
| **Miller's Law** | Long flat lists, unsectioned forms, cognitive overload |
| **Tesler's Law** | Missing format hints, no defaults, complexity pushed to user |
| **Jakob's Law** | Non-standard affordances, badge-styled buttons, wrong CTA placement |
| **Gestalt Laws** | Proximity/grouping violations, destructive actions styled like safe ones |
| **Serial Position Effect** | Unsorted results, critical fields buried mid-form |
| **Banner Blindness** | Red box errors, corner toasts, emoji-heavy empty states |
| **Weber's Law** | Imperceptible hover states, low-contrast selected states |

---

## Output

A structured markdown report with:
- **Executive Summary** — overall quality + biggest risk
- **Summary Table** — ✅/⚠️/❌ status for all 10 laws
- **Findings** — grouped by severity (🔴 Critical / 🟡 Medium / 🟠 Low), each with exact location, problem explanation, and specific code fix
- **Priority Fix List** — ordered by impact

---

## Install

### Claude Code
```bash
mkdir -p ~/.claude/skills/ux-laws-audit && curl -o ~/.claude/skills/ux-laws-audit/SKILL.md https://raw.githubusercontent.com/notacp/ux-laws-audit-skill/main/SKILL.md
```

### Gemini CLI
```bash
mkdir -p ~/.gemini/skills/ux-laws-audit && curl -o ~/.gemini/skills/ux-laws-audit/SKILL.md https://raw.githubusercontent.com/notacp/ux-laws-audit-skill/main/SKILL.md
```

### Codex CLI / Cursor / other agents
Download `SKILL.md` and place it in your agent's skills directory (varies by agent).

### Manual
1. Download `SKILL.md` from this repo
2. Place it in `<agent-skills-dir>/ux-laws-audit/SKILL.md`
3. Restart your agent

---

## Usage

The skill triggers automatically when you ask things like:

- *"Audit my UI for UX issues"*
- *"Review my design against UX laws"*
- *"What's wrong with my interface?"*
- *"Check my components for usability issues"*
- *"Is my UI good?"*

Mentioning any specific law ("check this for Fitts's Law") will also trigger a full audit.

**With code:**
```
Can you audit my search UI? Here are the components: [paste code]
```

**With description only** (no code required):
```
I have a mobile checkout form: small submit button, error shown at top of page,
promo code field in the middle of 8 payment fields. Anything wrong with it?
```

---

## License

MIT
