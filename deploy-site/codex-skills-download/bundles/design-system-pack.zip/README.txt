沉淀团队 UI 实现规则

适合长期协作，把组件、变量、颜色和实现规则固定下来。

包含 skills:
- 设计系统规则生成: skills/figma-create-design-system-rules.zip
- Figma 画布读写: skills/figma-use.zip
- UI/UX 设计智库: skills/ui-ux-pro-max.zip
