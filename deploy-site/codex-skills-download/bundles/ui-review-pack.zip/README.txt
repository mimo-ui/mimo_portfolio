输出清晰的 UI/UX 评审意见

适合评审页面、说明问题，并把设计价值讲清楚。

包含 skills:
- UX 法则审查: skills/ux-laws-audit.zip
- 新旧界面对比分析: skills/compare-ui-screens.zip
- 桌面截图工具: skills/screenshot.zip
