把竞品风格变成开发参考

适合拆解参考网站，把风格标准转成开发能理解的语言。

包含 skills:
- 网站风格提取: skills/extract-design.zip
- UI/UX 设计智库: skills/ui-ux-pro-max.zip
- 前端自动化验收: skills/playwright.zip
