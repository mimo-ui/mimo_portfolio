把 Figma 讲清楚并推动实现

适合把设计稿交给开发实现，并在交付后检查还原度。

包含 skills:
- Figma 工作流助手: skills/figma.zip
- Figma 设计稿转代码: skills/figma-implement-design.zip
- Figma UI 还原检查: skills/figma-ui-checker.zip
- 前端自动化验收: skills/playwright.zip
- 新旧界面对比分析: skills/compare-ui-screens.zip
